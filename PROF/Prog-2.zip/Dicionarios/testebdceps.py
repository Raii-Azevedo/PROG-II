def main():
	arq = open("bdcepsruas.txt","rt",encoding="utf-8")
	s = arq.read()
	print(s)
	return 0

main()