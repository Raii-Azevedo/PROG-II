
def main(args):
	print(args)
	
	print("HEllo world")
	return 0

if __name__ == '__main__':
    import sys
    sys.exit(main(sys.argv))
